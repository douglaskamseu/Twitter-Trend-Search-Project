import React from 'react';

class User extends React.Component {

	render() {

		return (

			<div>
				<div className="float-left">
					<button type="button" className="btn btn-outline-secondary">Log out</button>
				</div>

			</div>
		);
	}
}

export default User;