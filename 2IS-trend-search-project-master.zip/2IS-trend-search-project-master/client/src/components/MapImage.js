import React from 'react';


class MapImage extends React.Component {

	render() {

		return (

			<div>
				<img width="250" alt="World Map" src="https://www.psdgraphics.com/file/global-search-icon.jpg"/>
			</div>
		);
	}
}


export default MapImage;