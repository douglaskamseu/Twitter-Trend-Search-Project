import React from 'react';


class Title extends React.Component {

	

	render() {

		return (
			<div>
			<div className="d-flex justify-content-center title">
				<h1>Your Trend</h1>
			</div>
			</div>
		);
	}
}

	

export default Title;