import React from 'react';


class Logout extends React.Component {

	

	render() {

		return (

			<div>
				
			</div>
		);
	}
}

	

export default Logout;