
	$(function(){
    	$('.selectpicker').selectpicker();
	});
