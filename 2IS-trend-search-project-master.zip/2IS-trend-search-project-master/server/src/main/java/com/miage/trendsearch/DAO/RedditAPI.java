package com.miage.trendsearch.DAO;

import java.util.ArrayList;
import java.util.List;

public class RedditAPI {
    
    //--------------------------------------------------------------------
    //------------------------- WORK IN PROGRESS -------------------------
    //--------------------------------------------------------------------
    
    // Connect to Reddit API using login and password
    //Reddit reddit = new RedditTemplate(, );
       
    // Get the list of posts
    public List<String> getPosts(String keyword){
        List test = new ArrayList();
        return test;
    }
};

