package com.miage.trendsearch.utils;

public class Constantes {
    public final static String CONSUMERKEY = "o1YW2oOCl2G2LjjPsq1VoXhL5"; // The application's consumer key
    public final static String CONSUMERSECRET = "Zg880Z8sQcLSstXtrJSg6r9hGbaRunKO6hSzFbAn8Uqgv0lJCd"; // The application's consumer secret
    public final static String ACCESSTOKEN = "600978003-CPPuLG3e281CF0LPOFfA7s45rYA2AI82N27PuE8R"; // The access token granted after OAuth authorization
    public final static String ACCESSTOKEN_SECRET = "Kl3uIWDlzM3d4WtXOcsCIU37FwNPUis5p3RSqbFoPLrja"; // The access token secret granted after OAuth authorization
                
}
