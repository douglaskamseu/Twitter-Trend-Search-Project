package com.miage.trendsearch.DAO;

import java.util.ArrayList;
import java.util.List;

public class TumblrAPI {
    //--------------------------------------------------------------------
    //------------------------- WORK IN PROGRESS -------------------------
    //--------------------------------------------------------------------
    
    // Connect to Tumblr API using login and password
    //Tumblr tumblr = new TumblrTemplate(, );
       
    // Get the list of posts
    public List<String> getPosts(String keyword){
        List test = new ArrayList();
        return test;
    }
};

